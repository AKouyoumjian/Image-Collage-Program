package model;

import java.util.ArrayList;
import java.util.List;

/**
 * Class for a CollageLayer that represents an image with a position
 * relative to other layers.
 * The list of pixels are in lists of rows.
 */
public class CollageLayer implements ILayer {
  private final String name;
  private final List<List<IPixel>> originalPix; // original pixels before any filters applied
  // we keep track of original pixels so when filters are applied to an already filtered layer,
  // the filter is applied correctly to the original.
  private List<List<IPixel>> currentPix;
  private final int height;
  private final int width;
  private FilterOption filter;
  private final List<List<List<IPixel>>> originalImgs;
  private final List<int[]> coordImgs;

  /**
   * Constructor for a CollageLayer.
   *
   * @param pixels the image of this layer, represented via pixels. used to initialize the
   *               originalPix parameter, which a copy is made of to initialize the
   *               currentPix parameter
   * @param width  integer for this layer's width
   */
  public CollageLayer(String name, List<List<IPixel>> pixels, int height, int width) {
    if (name == null || pixels == null) {
      throw new IllegalArgumentException("Layer cannot have null value for its name or rows of" +
              " pixels.");
    }
    if (width <= 0 || height <= 0) {
      // checking if the provided width or height is invalid
      throw new IllegalArgumentException("Layer width and height must be greater than 0.");
    }
    // checking that pixels is not an empty list, or has empty rows
    if (pixels.size() == 0 || pixels.get(0).size() == 0) {
      throw new IllegalArgumentException("Cannot have a layer with no rows, or without an pixels"
              + " in one of its rows.");
    }
    // checking that all rows have the right amount of pixels for the specified width
    // ex: making sure a row doesn't only have 4 pixels, if the layer has a width of ten.
    for (int i = 0; i < pixels.size(); i++) {
      List<IPixel> row = pixels.get(i);
      if (row.size() != width) {
        throw new IllegalArgumentException("Row " + (i + 1) + " does not have an amount pixels"
                + " equal to the given width.");
      }
    }
    // making sure that provided width and height match pixel dimensions
    if (pixels.size() != height || pixels.get(0).size() != width) {
      throw new IllegalArgumentException("Provided height and width do not match the dimensions"
              + " of the given pixels.");
    }
    this.name = name;
    this.originalPix = pixels;
    this.height = height;
    this.width = width;
    this.filter = FilterOption.NORM;
    this.originalImgs = new ArrayList<>();
    this.coordImgs = new ArrayList<>();
    // the current pixels are initialized to a copy of the pixels provided
    this.currentPix = new ArrayList<>();
    for (int row = 0; row < this.height; row++) {
      List<IPixel> newRow = new ArrayList<>();
      for (int col = 0; col < this.width; col++) {
        IPixel pixCopy = this.getOriginalPixel(row, col).copy();
        newRow.add(pixCopy);
      }
      this.currentPix.add(newRow);
    }
  }

  /**
   * Constructor for CollageLayer with filterOption a passed, so you can instantiate
   * a layer with a filter already applied.
   * @param name   String for the name.
   * @param pixels the image of this layer, represented via pixels. used to initialize the
   *               *                    originalPix parameter, which a copy is made of to
   *                                    initialize the currentPix parameter
   * @param height int for layers height
   * @param width  integer for this layer's width
   */
  public CollageLayer(
          String name, List<List<IPixel>> pixels, FilterOption filter, int height, int width) {
    if (name == null || pixels == null) {
      throw new IllegalArgumentException("Layer cannot have null value for its name or rows of" +
              " pixels.");
    }
    if (width <= 0 || height <= 0) {
      // checking if the provided width or height is invalid
      throw new IllegalArgumentException("Layer width and height must be greater than 0.");
    }
    // checking that pixels is not an empty list, or has empty rows
    if (pixels.size() == 0 || pixels.get(0).size() == 0) {
      throw new IllegalArgumentException("Cannot have a layer with no rows, or without an pixels"
              + " in one of its rows.");
    }
    // checking that all rows have the right amount of pixels for the specified width
    // ex: making sure a row doesn't only have 4 pixels, if the layer has a width of ten.
    for (int i = 0; i < pixels.size(); i++) {
      List<IPixel> row = pixels.get(i);
      if (row.size() != width) {
        throw new IllegalArgumentException("Row " + (i + 1) + " does not have an amount pixels"
                + " equal to the given width.");
      }
    }
    // making sure that provided width and height match pixel dimensions
    if (pixels.size() != height || pixels.get(0).size() != width) {
      throw new IllegalArgumentException("Provided height and width do not match the dimensions"
              + " of the given pixels.");
    }
    this.name = name;
    this.originalPix = pixels;
    this.height = height;
    this.width = width;
    this.filter = filter;
    this.originalImgs = new ArrayList<>();
    this.coordImgs = new ArrayList<>();
    // the current pixels are initialized to a copy of the pixels provided
    this.currentPix = new ArrayList<>();
    for (int row = 0; row < this.height; row++) {
      List<IPixel> newRow = new ArrayList<>();
      for (int col = 0; col < this.width; col++) {
        IPixel pixCopy = this.getOriginalPixel(row, col).copy();
        newRow.add(pixCopy);
      }
      this.currentPix.add(newRow);
    }
  }

  @Override
  public String getName() {
    return this.name;
  }

  @Override
  public IPixel getOriginalPixel(int row, int col) throws IllegalArgumentException {
    if (row < 0 || col < 0) {
      throw new IllegalArgumentException("Cannot have a pixel with a negative row or column");
    }
    if (row > this.height) {
      throw new IllegalArgumentException("Row value is out-of-bounds for this layer.");
    }
    if (col > this.width) {
      throw new IllegalArgumentException("Column value is out-of-bounds for this layer.");
    }
    return this.originalPix.get(row).get(col);
  }

  @Override
  public int getHeight() {
    return this.height;
  }

  @Override
  public int getWidth() {
    return this.width;
  }

  @Override
  public void applyFilter(FilterOption f) {
    this.filter = f;
    if (f.toString().equals("normal")) {
      // if the user wants to see the unaltered state of the original image, initialize the current
      // display of pixels to be a copy of the original pixels
      this.currentPix = new ArrayList<>();
      for (int row = 0; row < height; row++) {
        List<IPixel> newRow = new ArrayList<>();
        for (int col = 0; col < width; col++) {
          IPixel pixCopy = this.getOriginalPixel(row, col).copy();
          newRow.add(pixCopy);
        }
        this.currentPix.add(newRow);
      }
    }
    // the case where the user wants to see some altered version of the original pixels
    // assigning the currently displayed pixels to a new ArrayList
    this.currentPix = new ArrayList<>();
    for (int row = 0; row < this.height; row++) {
      // creating the new row to be added to the currently displayed pixels
      List<IPixel> newRow = new ArrayList<>();
      //the row of the original pixels which corresponds to the row index
      List<IPixel> origRow = this.originalPix.get(row);
      for (int col = 0; col < this.width; col++) {
        // creating a copy of the original pixel at the column index, then applying the
        // given filter to it
        IPixel newPix = origRow.get(col).copy();
        newPix.apply(f);
        // adding the filtered copy of the original pixel to the new row of currently
        // displayed pixels
        newRow.add(newPix);
      }
      // adding the row of newly filtered original pixels to the 2d list of currently
      // displayed pixels
      currentPix.add(newRow);
    }
  }

  @Override
  public IPixel getPixel(int row, int col) throws IllegalArgumentException {
    if (row < 0 || col < 0) {
      throw new IllegalArgumentException("Cannot have a pixel with a negative row or column");
    }
    if (row > this.height) {
      throw new IllegalArgumentException("Row value is out-of-bounds for this layer.");
    }
    if (col > this.width) {
      throw new IllegalArgumentException("Column value is out-of-bounds for this layer.");
    }
    return this.currentPix.get(row).get(col);
  }

  @Override
  public FilterOption getFilter() {
    return this.filter;
  }

  @Override
  public String toString() {
    String str = this.name + " " + this.filter.toString() + "\n";

    for (int i = 0; i < originalPix.size(); i++) {
      for (int j = 0; j < originalPix.get(i).size(); j++) {
        str = str + originalPix.get(i).get(j).toString();
      }
    }
    return str;
  }

  @Override
  public List<List<IPixel>> getPixelArrayCopy() {
    List<List<IPixel>> list = new ArrayList<>();
    for (int i = 0; i < this.height; i++) {
      ArrayList<IPixel> embeddedList = new ArrayList<IPixel>();
      for (int k = 0; k < this.width; k++) {
        embeddedList.add(this.getPixel(i, k));
      }
      list.add(embeddedList);
    }
    return list;
  }

  @Override
  public void addImg(List<List<IPixel>> img, int x, int y) throws IllegalArgumentException {
    // throwing an exception if img is null
    if (img == null) {
      throw new IllegalArgumentException("Cannot use null as an image.");
    }
    // throwing an exception if the x/y are out-of-bounds
    if (x < 0 || y < 0 || x > this.width || y > this.height) {
      throw new IllegalArgumentException("Coordinate out-of-bounds. X/Y must be positive"
              + " and within the layer.");
    }
    // throwing an exception if the image has no rows of pixels
    int imgHeight = img.size();
    if (imgHeight == 0) {
      throw new IllegalArgumentException("Cannot use an image with empty rows of pixels.");
    }
    // throwing an exception if the image does not have rows which are all the same width
    int imgWidth = img.get(0).size();
    for (int row = 1; row < img.size(); row++) {
      if (imgWidth != img.get(row).size()) {
        throw new IllegalArgumentException("All image rows must contain"
                + " the same number of pixels.");
      }
    }
    // throwing an exception if all of the image's rows are empty
    if (imgWidth == 0) {
      throw new IllegalArgumentException("Cannot have an image with empty rows.");
    }
    // throwing an exception if the image is too big for this layer
    if (imgHeight * imgWidth > this.height * this.width) {
      throw new IllegalArgumentException("The image is larger than this layer.");
    }
    // throwing an exception if the image would not fully fit onto the layer,
    // because of its position
    int bottomSideBound = imgHeight + y;
    int rightSideBound = imgWidth + x;
    if (bottomSideBound > this.height || rightSideBound > this.width) {
      throw new IllegalArgumentException("The image cannot fit at this coordinate. Try a"
              + " new position.");
    }
    // first, add the unfiltered image to originalImages and
    // store its coordinates as an int[]. Each have the same
    // indexes in their Lists
    this.originalImgs.add(img);
    int[] coord = new int[]{x, y};
    this.coordImgs.add(coord);
    // applying the current filter to the image's pixels
    for (int imgRow = 0; imgRow < imgHeight; imgRow++) {
      for (int imgCol = 0; imgCol < imgWidth; imgCol++) {
        IPixel imgPixCopy = img.get(imgRow).get(imgCol);
        imgPixCopy.apply(this.filter);
        img.get(imgRow).set(imgCol, imgPixCopy);
      }
    }
    // iterating over the entire layer, only taking action on the layer's
    // pixels which will have the image's pixels merged onto them.
    // if they will, the current filter is applied to the image's pixel
    // before merging it with the one below it on the layer
    for (int layerRow = 0; layerRow < this.height; layerRow++) {
      for (int layerCol = 0; layerCol < this.width; layerCol++) {
        if (layerRow >= y && layerRow <= bottomSideBound - 1
                && layerCol >= x && layerCol <= rightSideBound - 1) {
          IPixel layerPix = this.getPixel(layerRow, layerCol);
          IPixel imgPix = img.get(layerRow - y).get(layerCol - x);
          IPixel mergedPix = imgPix.merge(layerPix);
          this.currentPix.get(layerRow).set(layerCol, mergedPix);
        }
      }
    }
  }
}