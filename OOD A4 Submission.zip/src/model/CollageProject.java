package model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Class for a src.main.Project consisting of a layers.
 * Layers at the front of the arrayList are on the bottom. Index 0 is the bottom-most layer.
 */
public class CollageProject implements IProject {
  private List<ILayer> layers;
  private String name;
  private final int height;
  private final int width;
  private int maxPixel;

  /**
   * Main constructor for Collage Project.
   * @param name string name
   * @param height int height
   * @param width int width
   */
  public CollageProject(String name, int height, int width) {
    this.layers = new ArrayList<>(Arrays.asList(this.makeBackgroundLayer(height, width)));
    this.name = name;
    this.height = height;
    this.width = width;
    this.maxPixel = 255; // max ppm pixel amount
    if (this.name == null) {
      throw new IllegalArgumentException("Name cannot be null.");
    }
  }

  /**
   * Alternative constructor for Collage Project for giving it a max alpha (not assuming it is 255).
   * @param name string name
   * @param height int height
   * @param width int width
   * @param maxPixels int maxPixels
   */
  public CollageProject(String name, int height, int width, int maxPixels) {
    this.layers = new ArrayList<>(Arrays.asList(this.makeBackgroundLayer(height, width)));
    this.name = name;
    this.height = height;
    this.width = width;
    this.maxPixel = maxPixels; // max ppm pixel amount
    if (this.name == null) {
      throw new IllegalArgumentException("Name cannot be null.");
    }
  }

  /**
   * Alternate constructor for Collage Project.
   * This is for when you want to make a collage with layers already made.
   * @param name string name
   * @param height height
   * @param width width
   * @param  layers layers
   */
  public CollageProject(String name, List<ILayer> layers, int height, int width) {
    this.layers = layers;
    this.name = name;
    this.height = height;
    this.width = width;
    this.maxPixel = 255; // max ppm pixel amount
  }


  /**
   * Returns all the layers of a project so it can be saved.
   *
   * @return
   */
  @Override
  public ArrayList<ILayer> returnAllLayers() {

    ArrayList<ILayer> list = new ArrayList<ILayer>();
    for (int i = 0; i < this.layers.size(); i++) {

      String name = this.layers.get(i).getName();
      FilterOption filter = this.layers.get(i).getFilter();
      List<List<IPixel>> pixels = this.layers.get(i).getPixelArrayCopy();

      ILayer current = new CollageLayer(name, pixels, filter,
              this.layers.get(i).getHeight(), this.layers.get(i).getWidth());


      list.add(current);

    }
    return list;
  }


  /**
   * Formats the project into Collager format.
   * @return the string formatted.
   */
  public String formatProject() {
    String format = this.name + "\n" + this.width + " " + this.height + "\n"
            + this.maxPixel + "\n";

    for (int i = 0; i < this.layers.size(); i++) {

      format = format + this.layers.get(i).toString();

    }

    return format;

  }

  @Override
  public void addLayer(String name) throws IllegalArgumentException {
    for (ILayer layer : this.layers) {
      if (layer.getName().equals(name)) {
        throw new IllegalArgumentException("A layer with the given name already exists.");
      }
    }
    List<List<IPixel>> newLayerPix = new ArrayList<>();
    for (int row = 0; row < this.height; row++) {
      List<IPixel> newRow = new ArrayList<>();
      for (int col = 0; col < this.width; col++) {
        newRow.add(new PixelImpl(255, 255, 255, 0));
      }
      newLayerPix.add(newRow);
    }
    this.layers.add(new CollageLayer(name, newLayerPix, this.height, this.width));
  }


  @Override
  public void addLayerImg(String layerName, List<List<IPixel>> img, int x, int y)
          throws IllegalArgumentException {
    if (layerName == null || img == null) {
      throw new IllegalArgumentException("Cannot have a null layer name or image.");
    }
    // img height can be tracked
    int imgHeight = img.size();
    // layer of interest is initialized to the bottom-most layer
    ILayer layer = this.layers.get(0);
    boolean match = false;
    for (int i = 0; i < this.layers.size(); i++) {
      if (this.layers.get(i).getName().equals(layerName)) {
        match = true;
        layer = this.layers.get(i);
      }
    }
    if (!match) {
      throw new IllegalArgumentException("A Layer with that name does not exist in this collage.");
    }
    if (x < 0 || y < 0) {
      throw new IllegalArgumentException("Cannot have negative x/y coordinates.");
    }
    if (x > layer.getWidth() || y > layer.getHeight()) {
      throw new IllegalArgumentException("Provided x/y coordinate is not on the layer.");
    }
    // the case where the image's rows do not all have the same width
    int imgWidth = img.get(0).size();
    for (int i = 1; i < imgHeight; i++) {
      if (img.get(i).size() != imgWidth) {
        throw new IllegalArgumentException("Image rows do not have the same amount of pixels.");
      }
    }
    // the case where the image is bigger than the layer
    if (imgHeight * imgWidth > layer.getHeight() * layer.getWidth()) {
      throw new IllegalArgumentException("Layer is not big enough to support this image.");
    }
    // the case where the image is NOT bigger than the layer, but when it is in a position in which
    // it would need to be cropped in order to fit on the layer
    if (layer.getHeight() - y < imgHeight || layer.getWidth() - x < imgWidth) {
      throw new IllegalArgumentException("Image must be placed in a different location to fit it "
              + " onto the layer.");
    }
    layer.addImg(img, x, y);
  }


  /**
   * This private method makes an all-white background layer
   * that is used as a default background when making a project.
   * @param height int height of the layer
   * @param width int width of the layer
   * @return the ILayer background
   */
  private ILayer makeBackgroundLayer(int height, int width) {

    List<List<IPixel>> list = new ArrayList<>();

    PixelImpl whitePix = new PixelImpl(255, 255, 255, 1);

    for (int i = 0; i < height; i++) {

      ArrayList<IPixel> inner = new ArrayList();

      for (int j = 0; j < width; j++) {
        inner.add(whitePix);
      }
      list.add(inner);
    }
    return new CollageLayer("background", list, height, width);
  }


  @Override
  public ILayer compressToImage(String name) {
    // bgAvgPix needs to be initialized (will be changed later in the method).
    List<List<List<IPixel>>> allPix = new ArrayList<>();
    // first, need to loop through each layer at a specific coordinate, to add all pixels at that
    // given coordinate to a list, and then add that list to a row, which contains these lists
    // all at their given coordinate.
    for (int pixRow = 0; pixRow < this.height; pixRow++) {
      List<List<IPixel>> newRow = new ArrayList<>();
      for (int pixCol = 0; pixCol < this.width; pixCol++) {
        List<IPixel> allCoordPix = new ArrayList<>();
        for (int l = 0; l < layers.size(); l++) {
          ILayer currentLayer = this.layers.get(l);
          IPixel currentPix = currentLayer.getPixel(pixRow, pixCol);
          allCoordPix.add(currentPix);
        }
        newRow.add(allCoordPix);
      }
      allPix.add(newRow);
    }
    // allPix contains all pixels of each layer as a list, with the pixels from the bg layer
    // at the first index of the list. so, the lists have to be traversed from the END.
    // now, creating a new layer which will be returned as the final image.
    List<List<IPixel>> finalImg = new ArrayList<>();
    for (int row = 0; row < this.height; row++) {
      List<IPixel> newRow = new ArrayList<>();
      for (int col = 0; col < this.width; col++) {
        // all the pixels at a certain coordinate, as a list
        List<IPixel> coordPix = allPix.get(row).get(col);
        for (int index = 0; index < coordPix.size() - 1; index++) {
          // for however many pixels there are at the coord, doing this process for each of them
          // first, the farthest back IPixel is initialized
          IPixel bgPix = coordPix.get(0);
          // then, the NEXT IPixel is initialized
          IPixel nextPix = coordPix.get(1);
          // now, they are merged
          IPixel merged = nextPix.merge(bgPix);
          // will set this to be the furthest back pixel
          coordPix.set(0, merged);
          // now, the one which was directly in front of the background pixel will be removed
          coordPix.remove(1);
        }
        // this is outside the loop, the complete pixel average is added to the new row
        newRow.add(coordPix.get(0));
      }
      finalImg.add(newRow);
    }
    return new CollageLayer(name, finalImg, this.height, this.width);
  }




  @Override
  public void applyFilterToCertainLayer(FilterOption f, String s) throws IllegalArgumentException {

    // this is the layer we will apply the filter to.
    // if it remains null then we know to throw illegalArg exception.
    ILayer layer = null;

    // find the layer which the instruction asks for
    for (ILayer l: this.layers) {
      if (l.getName().equals(s)) {
        layer = l;
      }
    }
    // if layer remains null, there is no layer w that name in Project so we throw exception.
    if (layer == null) {
      throw new IllegalArgumentException("No layer with given name exists in the Project.");
    }

    // finally, we apply the given filter to the layer.
    layer.applyFilter(f);
  }




}
