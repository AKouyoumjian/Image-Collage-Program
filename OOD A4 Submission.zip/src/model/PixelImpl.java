package model;


/**
 * This class represents a pixel that has RGB and A fields as integers.
 */
public class PixelImpl implements IPixel {
  private int r;
  private int g;
  private int b;
  private int a;
  private int maxValue;

  /**
   * Constructor for a pixel that takes in the integer values for rgba.
   *
   * @param r integer
   * @param g integer
   * @param b integer
   * @param a integer
   * @param maxValue integer
   */
  public PixelImpl(int r, int g, int b, int a, int maxValue) {
    this.r = r;
    this.g = g;
    this.b = b;
    this.a = a;
    this.maxValue = maxValue;
  }

  /**
   * Convenience Constructor FOR PPM PIXELS since they all have maxValue with 255.
   *
   * @param r integer
   * @param g integer
   * @param b integer
   * @param a integer
   */
  public PixelImpl(int r, int g, int b, int a) {
    this.r = r;
    this.g = g;
    this.b = b;
    this.a = a;
    this.maxValue = 255; // max value for all PPMs are 255
  }

  @Override
  public String toString() {
    return this.r + " " + this.g + " " + this.b + " " + this.a + "\n";
  }

  @Override
  public void apply(FilterOption f) {
    double value = this.getValue();
    double luma = this.getLuma();
    double intensity = this.getIntensity();
    switch (f.toString()) {
      case "normal":
        break;
      case "red-component":
        this.g = 0;
        this.b = 0;
        break;
      case "blue-component":
        this.g = 0;
        this.r = 0;
        break;
      case "green-component":
        this.r = 0;
        this.b = 0;
        break;

      case "brighten-value":

        this.r += value;
        this.r = this.clampMax(this.r, this.maxValue);

        this.g += value;
        this.g = this.clampMax(this.g, this.maxValue);

        this.b += value;
        this.b = this.clampMax(this.b, this.maxValue);

        break;
      case "darken-value":

        this.r -= value;
        this.r = this.clampMax(this.r, this.maxValue);

        this.g -= value;
        this.g = this.clampMax(this.g, this.maxValue);

        this.b -= value;
        this.b = this.clampMax(this.b, this.maxValue);

        break;

      case "brighten-luma":

        this.r += luma;
        this.r = this.clampMax(this.r, this.maxValue);

        this.g += luma;
        this.g = this.clampMax(this.g, this.maxValue);

        this.b += luma;
        this.b = this.clampMax(this.b, this.maxValue);

        break;
      case "darken-luma":

        this.r -= luma;
        this.r = this.clampMax(this.r, this.maxValue);

        this.g -= luma;
        this.g = this.clampMax(this.g, this.maxValue);

        this.b -= luma;
        this.b = this.clampMax(this.b, this.maxValue);

        break;

      case "brighten-intensity":

        this.r += intensity;
        this.r = this.clampMax(this.r, this.maxValue);

        this.g += intensity;
        this.g = this.clampMax(this.g, this.maxValue);

        this.b += intensity;
        this.b = this.clampMax(this.b, this.maxValue);

        break;
      case "darken-intensity":

        this.r -= intensity;
        this.r = this.clampMax(this.r, this.maxValue);

        this.g -= intensity;
        this.g = this.clampMax(this.g, this.maxValue);

        this.b -= intensity;
        this.b = this.clampMax(this.b, this.maxValue);

        break;

      default: // if it gets down here, it was an invalid filter name.
        throw new IllegalArgumentException("No filter with that name exists.");
    }
  }

  @Override
  public IPixel copy() {
    return new PixelImpl(this.r, this.g, this.b, this.a, this.maxValue);
  }

  @Override
  public IPixel merge(IPixel bgPix) {
    String[] bgPixStr = bgPix.toString().split(" ", -1);
    int dR = Integer.parseInt(bgPixStr[0]);
    int dG = Integer.parseInt(bgPixStr[1]);
    int dB = Integer.parseInt(bgPixStr[2]);
    double dA = Integer.parseInt(bgPixStr[3].replace("\n", ""));
    double a = this.a;

    double aPercent = ((a / this.maxValue) + (dA / this.maxValue) * (1 - (a / this.maxValue)));
    int newA = (int) (aPercent * this.maxValue);
    int newR = (int) ((a / this.maxValue) * r
            + dR * (dA / this.maxValue) * (1 - (a / this.maxValue)) * (1 / aPercent));
    int newG = (int) ((a / this.maxValue) * g
            + dG * (dA / this.maxValue) * (1 - (a / this.maxValue)) * (1 / aPercent));
    int newB = (int) ((a / this.maxValue) * b
            + dB * (dA / this.maxValue) * (1 - (a / this.maxValue)) * (1 / aPercent));

    return new PixelImpl(newR, newG, newB, newA, this.maxValue);
  }

  @Override
  public double getValue() {
    int maxOfTwo = Math.max(this.r, this.g);
    return Math.max(maxOfTwo, this.b);
  }

  @Override
  public double getLuma() {
    return 0.2126 * this.r + 0.7152 * this.g + 0.0722 * this.b;
  }

  @Override
  public double getIntensity() {
    return (this.r + this.g + this.b) / 3;
  }


  @Override
  public int getMaxValue() {
    return this.maxValue;
  }

  /**
   * This helper method returns the current int, if it is over the max it sets it back to the max.
   * @param current current int
   * @param max max int
   * @return
   */
  private int clampMax(int current, int max) {
    if (current > max) {
      return max;
    }
    else {
      return current;
    }
  }


}
