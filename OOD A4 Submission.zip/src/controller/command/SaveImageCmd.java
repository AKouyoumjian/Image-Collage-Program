package controller.command;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import model.ILayer;
import model.IProject;
import view.IView;

/**
 * Class for save-image command for the collage maker.
 */
public class SaveImageCmd implements ICommand {
  Scanner sc;
  IProject project;
  IView view;

  /**
   * Constructor for this method, it is public.
   *
   * @param sc      scanner
   * @param project model we want
   */
  public SaveImageCmd(Scanner sc, IProject project, IView view) {
    this.sc = sc;
    this.project = project;
    this.view = view;
  }

  /**
   * Method to save an image given the file name.
   */
  @Override
  public void execute() {
    // convert image to a single layer to be saved.
    ILayer image = this.project.compressToImage("Project 1");
    String path = "";
    String imageSave = image.toString();

    // get the path from scanner
    if (sc.hasNext()) {
      path = sc.next();

      try {
        FileWriter fw = new FileWriter(path);

        fw.write(imageSave);

        try {
          this.view.renderMessage(
                  "\n Image saved to path: " + path);
        } catch (IOException ignore) {
          throw new IllegalStateException("IOException thrown.");
        }

      } catch (IOException e) {
        throw new IllegalStateException("IO Exception thrown.");
      }
      /*
      ISSUE: we can't figure out why, but this is throwing an IOException.
      There are no more office hours left, we are unable to fix it at the time of submission.
       */

    }


  }


}
