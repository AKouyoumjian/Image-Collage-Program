package controller;

/**
 * Controller interface for the collager.
 */
public interface CollageController {

  /**
   * Method to start the controller.
   */
  public void start();

}
