Jason Snyder and Alex Kouyoumjian

Assignment 4 Collager Design Description

MODEL / VIEW

- We created an Enumeration for FilterOption since there is a finite number of options (8).

- We created an IPixel interface and PixelImpl class represent a pixel with rgba fields, and a maxValue field so we can
know what the maximum value rgb can be when doing our clamping.

- We implemented an ILayer interface and a CollageLayer class which uses an
ArrayList of ArrayList<IPixel> to represent the picture. It also keeps track of the original image
in case later on, we need to add revert/redo functionality.

- We created an IProject interface and CollageProject class that represents the Collager model,
containing a list of ILayer along with other informative fields about the project.

- We created the interfaces ILayer, IProject, and IView. These detail the methods to use for a
  visual project's layers, methods to use on the project itself, and methods for rendering a
  view of the project or messages to the user.


CONTROLLER:

- Interface CollageController was created, with implementation of ControllerImpl for the Collager.

- We used the command design pattern to facilitate the "text based scripting" operations in
the controller to ICommands. The user's collage instructions are handled this way.
- Since these commands are part of the controller, they have access to the model and view if needed.
The commands for new-project and load-project do not have separate classes because they
need to be in the ControllerImpl class so that they can mutate the controller's model.

OTHER:

Main: A main method in RunCollage runs the collager.

Utilities: We altered the given ImageUtil.java's readPpm method to return a list<list<IPixel>>
           so that we can use it to convert ppm to the model easily.



Script to run the program on Mac OS

// run the main method in RunCollage class
1. main().

// enter any button to continue.
1.5 "a"

// you'll be prompted with the welcomeMessage and asked to input an instruction or quit.
// type quit to test the quit functionality before a collage has been made.
2. "quit"


// run the main method in RunCollage class again
3. main() again.

// before each input, you will be prompted to input an instruction or quit.
// creates a new project with width = 400, height = 300
4. enter "new-project 400 300"


// adds a layer with the name myLayer1
5. "add-layer myLayer1"


// You would need to create a folder called documents, and add an image called myImageName.ppm
// in order to use this command on your computer.
//Adds the image at (0,0) to layer 1 with name potato
6. "add-image-to-layer layer1 potato Document/myPotatoImage.ppm 0 0"


// add image to a layer that does not exist.
7. "add-image-to-layer layerWRONG potato Document/myPotatoImage.ppm 0 0"


//you should get a message saying that there is no layer with that name, try again.
// add image to existing layer1 at 200 100.
8. "add-image-to-layer layer1 tomato Document/myTomatoImage.ppm 200 100"

// now add a new layer
9. "add-layer myLayer2"

// set filter to myLayer1
10. set-filter myLayer1 green-component

// now we save the final image to the path documents/newFinalImage
11. save-image Documents/food.ppm

// now save the project
12. save-project Documents/foodCollage.collage

// quit the program
13. quit

// now test load project
14. load-project Documents/foodCollage.collage

// now exit the program
15. quit