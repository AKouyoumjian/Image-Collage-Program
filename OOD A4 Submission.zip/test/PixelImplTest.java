import org.junit.Before;

import model.FilterOption;
import model.IPixel;
import model.PixelImpl;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotEquals;
import static org.junit.Assert.fail;

/**
 * Test class for methods in PixelImpl class.
 */
public class PixelImplTest {

  IPixel topLeft;
  IPixel topCent;
  IPixel topRight;
  IPixel midLeft;
  IPixel midCent;
  IPixel midRight;
  IPixel botLeft;
  IPixel botCent;
  IPixel botRight;

  IPixel testPix1;

  @Before
  public void init() {
    topLeft = new PixelImpl(0, 0, 255, 255);
    topCent = new PixelImpl(0, 255, 255, 255);
    topRight = new PixelImpl(255, 255, 255, 100);
    midLeft = new PixelImpl(100, 100, 100, 20);
    midCent = new PixelImpl(100, 100, 100, 50);
    midRight = new PixelImpl(100, 100, 100, 80);
    botLeft = new PixelImpl(255, 170, 90, 0);
    botCent = new PixelImpl(90, 255, 170, 0);
    botRight = new PixelImpl(170, 90, 255, 0);

    testPix1 = new PixelImpl(170, 90, 155, 0);

  }

  @org.junit.Test
  public void testToString() {
    assertEquals("0 0 255 255\n", topLeft.toString());
    assertEquals("170 90 255 0\n", botRight.toString());
  }

  @org.junit.Test
  public void testApply() {
    // testing that an exception is thrown when the given filter option does not exist
    try {
      topRight.apply(FilterOption.ERROR);
      fail("Failed to throw an exception for unsupported filter.");
    } catch (IllegalArgumentException e) {
      // do nothing
    }
    topRight.apply(FilterOption.NORM);
    assertEquals("255 255 255 100\n", topRight.toString());
    topRight.apply(FilterOption.RED);
    assertEquals("255 0 0 100\n", topRight.toString());
  }

  @org.junit.Test
  public void testGetMaxValue() {
    assertEquals(255, topLeft.getMaxValue());
    assertEquals(255, topRight.getMaxValue());
    assertEquals(255, topCent.getMaxValue());
  }

  @org.junit.Test
  public void testCopy() {
    IPixel tlCopy = topLeft.copy();
    // checking that a separate object has been made
    assertNotEquals(topLeft, tlCopy);
    tlCopy.apply(FilterOption.RED);
    // checking that applying a filter to a copy alters it, but not the original
    assertEquals("0 0 0 255\n", tlCopy.toString());
    assertNotEquals("0 0 0 255\n", topLeft.toString());
  }

  @org.junit.Test
  public void testMerge() {
    IPixel result1 = new PixelImpl(110, 110, 110, 112, 255);
    assertEquals(result1.toString(), topRight.merge(midLeft).toString());
    // testing that the new pixel values do not go above the max value
    IPixel max = new PixelImpl(255, 255, 255, 255, 255);
    IPixel result2 = new PixelImpl(255, 255, 255, 255, 255);
    assertEquals(result2.toString(), max.merge(max).toString());
  }

  // write tests for getValue, luma, and intensity, getMaxValue

  /**
   * Test for get value method.
   */
  @org.junit.Test
  public void testGetValue() {
    assertEquals(255, botLeft.getValue(), .01);
    assertEquals(100, midCent.getValue(), .01);
    assertEquals(170, testPix1.getValue(), .01);
  }


  /**
   * Test for get luma method.
   */
  @org.junit.Test
  public void testGetLuma() {
    assertEquals(182.3, botLeft.getLuma(), .01);
    assertEquals(100, midCent.getLuma(), .01);
    assertEquals(111.7, testPix1.getLuma(), .01);
  }

  /**
   * Test for get intensity method.
   */
  @org.junit.Test
  public void testGetIntensity() {
    assertEquals(171, botLeft.getIntensity(), .01);
    assertEquals(100, midCent.getIntensity(), .01);
    assertEquals(138, testPix1.getIntensity(), .01);
  }


}